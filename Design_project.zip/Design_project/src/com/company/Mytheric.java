package com.company;

import java.util.ArrayList;

public class Mytheric extends Character {
	
	int power_level;
	
	Mytheric(){
	
	}
	
	Mytheric(String name, String description, ArrayList<Objects> inventory, int pow ){
		super(name, description,inventory);
		this.power_level=pow;
	}
	
}

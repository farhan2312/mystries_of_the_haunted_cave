package com.company;

import java.util.Scanner;

public class main {

    public static void main (String[] args) {

        Watch w = Watch.getInstance();
        Robot r = new Robot("R2D2", 0.9f,w);
        Player p = Player.createplayer(w);
        TheDeathStar tds = TheDeathStar.getInstance();
        Wayfinder Wf= new Wayfinder();
        DataTape DT= new DataTape();
        //Watch w, Player p, TheDeathStar TDS,  Wayfinder Wf, DataTape DT){

        UI ui = UI.getInstance(w,r,p,tds,Wf,DT);

        TheMillenniumFalconL m = TheMillenniumFalconL.getInstance();
        m.objects.add(r);


        Scanner sc= new Scanner(System.in);

        //start game
        p.start_game();

        while(true) {
            if(w.gettime()==0) {

                System.out.println("GAME OVER");

                return;
            }
            System.out.print(">");
            String line = sc.nextLine();
            String[] lines = line.split(" ");
            String command = lines[0];

            try {
                if(command.equals("look")|| command.equals("Look")) {

                    if(lines.length>=2) {

                        throw new Exception();

                    }

                    else {

                        p.look();
                    }


                }
            }catch(Exception a) {

                System.out.println("Iook?");
            }


            try {
                if(lines[0].equals("search")|| lines[0].equals("Search")) {

                    if(lines.length>2) {

                        throw new Exception();

                    }

                    else {

                        p.searchCharacter(lines[1]);
                    }

                }
            }catch(Exception b) {

                System.out.println("Invalid Command. Did you mean: search <Character name>?");
            }

            //inspectObject
            try {
                if(lines[0].equals("inspect")|| lines[0].equals("Inspect")) {

                    if(lines.length!=2) {

                        throw new Exception();
                    }

                    else {
                        p.inspectObject(lines[1]);
                    }
                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean inspect <object>?");
            }



            //acquire object

            try {
                if(lines[0].equals("acquire")|| lines[0].equals("Acquire")) {

                    if(lines.length!=2) {

                        throw new Exception();
                    }

                    else {
                        p.acquireObject(lines[1]);
                    }
                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean acquire <object>?");
            }



            //fightCharacter
            try {
                if(lines[0].equals("fight")|| lines[0].equals("Fight")) {

                    if(lines.length!=4) {

                        throw new Exception();
                    }

                    else {
                        p.fightCharacter(lines[1], lines[3]);
                    }
                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean fight <Character> for <Object>?");
            }



            //
            try {
                if(lines[0].equals("request")|| lines[0].equals("Request")) {

                    if(lines.length!=4) {

                        throw new Exception();
                    }

                    else {
                        p.requestObject(lines[1],lines[3]);
                    }
                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean request <Object> from <Character>?");
            }


            //board millennium falcon
            try {
                if(lines[0].equals("board")|| lines[0].equals("Board")) {

                    if(lines.length!=4) {

                        throw new Exception();
                    }

                    else {
                        p.board();
                    }
                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean board the Millennium Falcon?");
            }




            try {
                if(lines[0].equals("exit")|| lines[0].equals("Exit")) {

                    if(lines.length>1) {

                        throw new Exception();
                    }

                    System.out.println("exiting...");
                    System.exit(0);

                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean exit?");
            }


            try {
                if(lines[0].equals("Wayfinder")|| lines[0].equals("wayfinder")) {

                    boolean found = false;
                    if(lines.length>1) {

                        throw new Exception();
                    }
                    else {

                        for(int i=0; i< p.inventory.size(); i++) {

                            if("Wayfinder".equals(p.inventory.get(i).name)) {

                                Wayfinder wf = new Wayfinder();
                                wf.listlocations();
                                found = true;
                                break;
                            }

                        }

                        if(!found) {

                            System.out.println("You don't have a Wayfinder. This is a rare item which only Darth Vader has. "
                                    + "\nTry fighting Darth Vader for the Wayfinder if you dare ;)");
                        }

                    }

                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean exit?");
            }




            try {
                if(lines[0].equals("Data_Tape")|| lines[0].equals("data_tape")) {

                    boolean found = false;
                    if(lines.length!=1) {

                        throw new Exception();
                    }
                    else {

                        for(int i=0; i< p.inventory.size(); i++) {

                            if("Data_Tape".equals(p.inventory.get(i).name)) {

                                DataTape dt = new DataTape();
                                dt.Displayinformation();
                                found = true;
                                break;
                            }

                        }

                        if(!found) {

                            System.out.println("You don't have a Data tape. This is an item owned by princess lea. Try requesting the data tape.");
                        }

                    }

                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean Data_Tape?");
            }


            //get code

            try {
                if(lines[0].equals("get")|| lines[0].equals("Get")) {

                    if(lines.length!=2) {

                        throw new Exception();
                    }

                    else {
                        p.getcode(r);
                    }
                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean get code?");
            }




            //decode
            try {
                if(lines[0].equals("decode")|| lines[0].equals("Decode")) {

                    if(lines.length!=2) {

                        throw new Exception();
                    }

                    else {
                        p.decode(lines[1], r);
                    }
                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean decode <Data_Tape>");
            }



            //self destruct
            try {
                if(lines[0].equals("initiate")|| lines[0].equals("Initiate")) {

                    if(lines.length!=3) {

                        throw new Exception();
                    }

                    else {
                        p.destruct();
                    }
                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean Initiate self-destruct code?");
            }




        }


    }
}

package com.company;

import java.util.ArrayList;

	
public class UI implements Observer {

		
	Watch w;
	Player p;

		 
	private static UI instance;
		
	private UI(Watch w, Player p){
			
		this.w = w;
		w.registerObserver((Observer)this);
		
		this.p = p;
		p.registerObserver((Observer)this);
		
	}
		
		
	public static synchronized UI getInstance(Watch w, Player p){
			
			if(instance == null){
				instance = new UI(w,p);
				}
			return instance;
	}
		

	public void update(String s) {
			System.out.println(s);
			
		}


	@Override
	public void update(int j) {
		// TODO Auto-generated method stub
		System.out.println(j);
	}
		

	}


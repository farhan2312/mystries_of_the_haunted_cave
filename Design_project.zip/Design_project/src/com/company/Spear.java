package com.company;

public class Spear extends Weapon{
	

	public Spear() {
	       super("Spear","Weapon","Fight invaders");
	    }
	
}

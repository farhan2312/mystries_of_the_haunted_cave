package com.company;

public class Objects {

    String name;
    String type;

    public Objects()
    {

    }
    public Objects(String name, String type)
    {
        this.name = name;
        this.type = type;
    }

}

package com.company;

import java.util.ArrayList;

public class Character extends ConcreteSubject{
	
	String name;
	String description;
	ArrayList<Objects> inventory;
	
	Character(String n, String des, ArrayList<Objects> inventory){
		this.name=n;
		this.description=des;
		this.inventory = inventory;
	}
	Character(){
	}
}

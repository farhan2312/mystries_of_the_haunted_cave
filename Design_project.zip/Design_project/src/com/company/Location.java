package com.company;

import java.util.ArrayList;

public class Location {

    String name;
    String description;
    ArrayList<Character> characters;  //characters in the location
    ArrayList<Object> objects;  //objects in the location
    ArrayList<Transport> transport; //transport in the location

    Location(){

       // observers = new ArrayList();
    }
}



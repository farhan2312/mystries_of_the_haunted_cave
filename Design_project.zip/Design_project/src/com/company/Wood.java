package com.company;

public class Wood extends Objects {

    int quantity;
    public Wood()
    {
        super("Wood","Consumable");
        quantity = 0;
    }
    public Wood(int q)
    {
        quantity = q;
    }

    public void AddWood()
    {
        quantity++;
    }
    public void DepleteWood()
    {
    	quantity--;
    }


}

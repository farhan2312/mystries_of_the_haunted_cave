package com.company;

public class ConcreteObserver implements Observer {


    private Subject subject;
    public ConcreteObserver(Subject subject)
    {
        this.subject = subject;
        subject.registerObserver(this);
    }

    @Override
    public void update(String name) {
        System.out.println("Do nothing from "+this);

    }

	@Override
	public void update(int j) {
		// TODO Auto-generated method stub
		System.out.println("Do nothing from "+this);
	}

   
}

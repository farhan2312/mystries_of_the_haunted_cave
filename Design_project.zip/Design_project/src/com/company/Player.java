package com.company;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;


public class Player extends Character{

	Location location = new Location();
	// TheMillenniumFalcon falcon = TheMillenniumFalcon.getInstance();

	protected ArrayList observers;
	Watch w;
	private Player(Watch w){
		this.w = w;
		//     location = TheDeathStar.getInstance();//player starts off at DeathStar
		Scanner scc= new Scanner(System.in);
		System.out.print("Enter Player name: ");
		name = scc.next();
	}


	public static Player createplayer(Watch w) {

		return new Player(w);

	}


	public void start_game() {


		String Game_Message ="                                                                                                                                                                                                                                       \n" +
				"@@@       @@@@@@@@   @@@@@@@@  @@@@@@@@  @@@  @@@  @@@@@@@       @@@@@@   @@@@@@@@     @@@@@@@  @@@  @@@  @@@@@@@@     @@@  @@@   @@@@@@   @@@  @@@  @@@  @@@  @@@@@@@  @@@@@@@@  @@@@@@@       @@@@@@@   @@@@@@   @@@  @@@  @@@@@@@@  \n" +
				"@@@       @@@@@@@@  @@@@@@@@@  @@@@@@@@  @@@@ @@@  @@@@@@@@     @@@@@@@@  @@@@@@@@     @@@@@@@  @@@  @@@  @@@@@@@@     @@@  @@@  @@@@@@@@  @@@  @@@  @@@@ @@@  @@@@@@@  @@@@@@@@  @@@@@@@@     @@@@@@@@  @@@@@@@@  @@@  @@@  @@@@@@@@  \n" +
				"@@!       @@!       !@@        @@!       @@!@!@@@  @@!  @@@     @@!  @@@  @@!            @@!    @@!  @@@  @@!          @@!  @@@  @@!  @@@  @@!  @@@  @@!@!@@@    @@!    @@!       @@!  @@@     !@@       @@!  @@@  @@!  @@@  @@!       \n" +
				"!@!       !@!       !@!        !@!       !@!!@!@!  !@!  @!@     !@!  @!@  !@!            !@!    !@!  @!@  !@!          !@!  @!@  !@!  @!@  !@!  @!@  !@!!@!@!    !@!    !@!       !@!  @!@     !@!       !@!  @!@  !@!  @!@  !@!       \n" +
				"@!!       @!!!:!    !@! @!@!@  @!!!:!    @!@ !!@!  @!@  !@!     @!@  !@!  @!!!:!         @!!    @!@!@!@!  @!!!:!       @!@!@!@!  @!@!@!@!  @!@  !@!  @!@ !!@!    @!!    @!!!:!    @!@  !@!     !@!       @!@!@!@!  @!@  !@!  @!!!:!    \n" +
				"!!!       !!!!!:    !!! !!@!!  !!!!!:    !@!  !!!  !@!  !!!     !@!  !!!  !!!!!:         !!!    !!!@!!!!  !!!!!:       !!!@!!!!  !!!@!!!!  !@!  !!!  !@!  !!!    !!!    !!!!!:    !@!  !!!     !!!       !!!@!!!!  !@!  !!!  !!!!!:    \n" +
				"!!:       !!:       :!!   !!:  !!:       !!:  !!!  !!:  !!!     !!:  !!!  !!:            !!:    !!:  !!!  !!:          !!:  !!!  !!:  !!!  !!:  !!!  !!:  !!!    !!:    !!:       !!:  !!!     :!!       !!:  !!!  :!:  !!:  !!:       \n" +
				" :!:      :!:       :!:   !::  :!:       :!:  !:!  :!:  !:!     :!:  !:!  :!:            :!:    :!:  !:!  :!:          :!:  !:!  :!:  !:!  :!:  !:!  :!:  !:!    :!:    :!:       :!:  !:!     :!:       :!:  !:!   ::!!:!   :!:       \n" +
				" :: ::::   :: ::::   ::: ::::   :: ::::   ::   ::   :::: ::     ::::: ::   ::             ::    ::   :::   :: ::::     ::   :::  ::   :::  ::::: ::   ::   ::     ::     :: ::::   :::: ::      ::: :::  ::   :::    ::::     :: ::::  \n" +
				": :: : :  : :: ::    :: :: :   : :: ::   ::    :   :: :  :       : :  :    :              :      :   : :  : :: ::       :   : :   :   : :   : :  :   ::    :      :     : :: ::   :: :  :       :: :: :   :   : :     :      : :: ::   \n" +
				"                                                                                                                                                                                                                                       ";

		notifyObservers(Game_Message);
		notifyObservers("You've woken up dazed. You look around, you're in an empty cave. It's dark and murky");
		notifyObservers("Enter a command (try look)");

	}


	public void look(){

		// The player can “look” to know the location’s description and characters/objects present.
		// Objects can exist in a location or in a character’s inventory.

		notifyObservers("You are in "+ location.name+ " which is a "+location.description+"\n");

		if(location.characters.size()!=0) {
			notifyObservers("At "+ location.name+" you find:");
			for(int i=0; i<location.characters.size();i++) {
				System.out.print(location.characters.get(i).name+" who ");
				System.out.print(location.characters.get(i)+"\n");

			}
		}
		else {

			notifyObservers("This place looks deserted. There's no one around...");
		}

		if(location.objects!=null) {

			notifyObservers("\nYou found the following objects:\n");
			notifyObservers("--Some objects may have a quantity > 1");
			for(int i=0; i<location.objects.size(); i++) {

				notifyObservers(location.objects.get(i).name+" ");

			}
		}

		else {

			notifyObservers("There are no objects around. Stop looking");
		}



	}

	public void searchCharacter(String name) {

		int i ;
		Boolean found = false;
		Boolean inventory_found = false;
		for(i=0; i< location.characters.size();i++) {

			if(name.equals(location.characters.get(i).name)){
				found = true;
				if(location.characters.get(i).inventory!=null) {
					inventory_found = true;
					notifyObservers(name+ " has the following inventory: ");
					for(int j=0; j<location.characters.get(i).inventory.size();j++) {

						System.out.print(location.characters.get(i).inventory.get(j).name+" ");

					}
					notifyObservers(" ");
				}
				break;
			}

		}

		if(!found) {
			notifyObservers("Character is not at this location!");
		}
		if(found && !inventory_found) {

			notifyObservers("OOPS "+name+" does not have anything in their inventory!");
		}

	}

	public void inspectObject(String obj) {

		//inspect objects in location
		Boolean foundinloc = false;
		if(location.objects!=null) {
			for(int i =0; i<location.objects.size();i++) {
				if(obj.equals(location.objects.get(i).name)){

					notifyObservers(location.objects.get(i).description);
					foundinloc = true;
					break;
				}

			}
		}

		Boolean foundininven = false;
		//inspect objects in inventory
		if(!foundinloc) {
			for(int i =0; i<location.characters.size();i++) {

				if(location.characters.get(i).inventory!=null) {

					for(int j =0; j<location.characters.get(i).inventory.size();j++) {


						if(obj.equals(location.characters.get(i).inventory.get(j).name)){

							notifyObservers(location.characters.get(i).inventory.get(j).description+"\n");
							foundininven = true;
							return;

						}
					}

				}
			}

		}

		//inspect objects in player in inventory
		if(!foundinloc && !foundininven) {

			if(inventory!=null) {

				for(int i =0; i<inventory.size();i++) {

					if(obj.equals(inventory.get(i).name)){

						notifyObservers(inventory.get(i).description+"\n");
						foundininven = true; //we're using the same boolean variable for player and character inventory
						return;

					}
				}

			}


		}




		//if user is inspecting an object that is neither in their inventory nor their location
		if(!foundinloc && !foundininven) {

			notifyObservers("What is a/an "+ obj+"? No such thing exists in your location, your inventory, or any available character inventory");
		}



	}

	public void acquireObject(String obj) {

		Boolean acquire_found = false;

		if(location.objects!=null) { //only enter if location has any objects
			for(int i =0; i<location.objects.size();i++) {
				if(obj.equals(location.objects.get(i).name)){

					if(obj.equals("Wayfinder")) {

						notifyObservers("You cannot acquire Wayfinder! You must fight Darth Vader first!");
						return;
					}

					inventory.add(location.objects.get(i)); //add object to inventory
					location.objects.remove(i); //remove object from location
					acquire_found = true; //object was found in location
					notifyObservers(obj+ " was added to your inventory\n");
					notifyObservers("Your inventory now has the following items:\n");
					for(int j=0; j<inventory.size(); j++) { //printing out player's inventory

						notifyObservers(inventory.get(j).name+" ");

					}
					notifyObservers(" ");
					break;
				}

			}

		}
		else {

			notifyObservers("There aren't any objects in your location!!!");
			return;
		}

		//if user is trying to acquire an object that does not exist in their location
		if(!acquire_found) {

			notifyObservers("You are trying to acquire an object that does not exist in your location!");
		}


	}
	//The player can “request <object> from <character>” to acquire an object that is already in another character’s inventory.
	public void requestObject(String obj, String chara){

		Boolean foundchar = false;
		Boolean foundobj = false;
		//CHECK IF SITH LORD!
		for(int i=0; i<location.characters.size();i++) {

			if(chara.equals(location.characters.get(i).name)) {

				if(chara.equals("Princess_Leia_Organa") && obj.equals("Light_Saber") ) {

					notifyObservers("Princess Leia has a Light_Saber but does not carry it in her inventory. Try requesting a light saber from someone else");
					return;
				}

				if(location.characters.get(i).chartype=="Sith") {

					notifyObservers("You cannot request an item from a Sith! You must fight "+ location.characters.get(i).name);
					return;
				}


				for(int j =0; j< location.characters.get(i).inventory.size(); j++) {

					if(obj.equals(location.characters.get(i).inventory.get(j).name)) {

						notifyObservers(chara+" has agreed to offer you their "+obj);
						foundobj = true;
						inventory.add(location.characters.get(i).inventory.get(j));
						location.characters.get(i).inventory.remove(location.characters.get(i).inventory.get(j));

						notifyObservers(obj+ " was added to your inventory\n");
						notifyObservers("Your inventory now has the following items:\n");
						for(int k=0; k<inventory.size(); k++) { //printing out player's inventory

							notifyObservers(inventory.get(k).name+" ");

						}
						notifyObservers(" ");


						break;
					}
				}
				foundchar = true;
				break;
			}
		}

		if(!foundchar) {
			notifyObservers(chara+" is not in this location.... You are talking to yourself :/");
		}
		else if(!foundobj) {
			notifyObservers(chara+" does not have a/an "+ obj+" in their inventory! Ask for something else maybe?");
		}

	}

	//	Object cannot be acquired from Sith lords. “fight <character> for <object>” can be used to do so,
	//but only if the player already has a weapon in their inventory.
	public void fightCharacter(String chara, String obj) {

		Boolean foundweapon=false, foundchar=false, isSith=false;
		int index=0;
		for(int i=0; i<location.characters.size();i++) {

			if(chara.equals(location.characters.get(i).name)) {

				foundchar = true;//character exists in current location
				if(location.characters.get(i).chartype == "Sith") {//if character to fight is a sith lord

					isSith = true;
					index = i;

					break;
				}

				break;
			}
		}


		for(int j=0; j<inventory.size();j++) {//search through inventory

			if(inventory.get(j).objtype=="Weapon") {//if inventory contains a weapon
				foundweapon = true;
				break;

			}

		}

		if(!foundchar) {

			notifyObservers(chara+" is not here! You're trying to fight the air...you look goofy");
		}

		else if(!foundweapon && !isSith) {

			notifyObservers("You're trying to fight a non-Sith AND WITHOUT A WEAPON???");
		}

		else if(!foundweapon) {

			notifyObservers("Are you seriously trying to fight without a weapon?? You have a death wish don't you?");
		}

		else if(!isSith) {

			notifyObservers("I'm not the most peaceful \"being\", but even I wouldn't fight a non-Sith!\nRethink your choices tsk tsk");
		}

		else {


			Boolean inInven = false;
			for(int k=0; k<location.characters.get(index).inventory.size(); k++) {

				if(obj.equals(location.characters.get(index).inventory.get(k).name)) {
					notifyObservers("You have defeated "+ chara);
					inventory.add(location.characters.get(index).inventory.get(k));
					location.characters.get(index).inventory.remove(location.characters.get(index).inventory.get(k));
					inInven = true;
					break;
				}

			}
			if(!inInven) {

				notifyObservers(chara+ " does not have a/an "+ obj);
				return;
			}
			notifyObservers(obj+ " was added to your inventory\n");
			notifyObservers("Your inventory now has the following items:\n");
			for(int k=0; k<inventory.size(); k++) { //printing out player's inventory

				notifyObservers(inventory.get(k).name+" ");

			}
			notifyObservers(" ");

		}
	}


	/*	In order to travel, the player must first “board Millennium Falcon” and then “travel to <location>”.
	 * The location of the Millennium Falcon changes to the location the player wants to travel to.*/

	public void board() {

		notifyObservers("Welcome aboard the Millennium Falcon!\n");
		notifyObservers(".                  &&&&&&&&&     &&&&&&&&&&&@                          \r\n"
				+ "                          &&.      (&*    @&@       @&@                         \r\n"
				+ "                        %&&        (&#    @&@        /&&                        \r\n"
				+ "                       @@  @##@    (&@    @&@   %# /&  &&,                      \r\n"
				+ "                     %&@  @    @   #&@    @&@  ,,   ,.  @&#                     \r\n"
				+ "                    @&(    ,#/    @&&     ,&@            @&@                    \r\n"
				+ "                  .&&.       ,&&&&&&%      @&&&@&/.       @&@ *@@@&@,           \r\n"
				+ "                 (&@   ,@&&&&/    /&&      @@     ,&@&&%   #&&&@  .&&.          \r\n"
				+ "                %&&@&&&@,  (@%    .&&      @@          .@&@ *&@     @&.         \r\n"
				+ "               %&&&@(   (*         @&      @@             #&&&( ,    &&.        \r\n"
				+ "              #&&&    ,(#*         @@      &@      *@@@#    @&.(&     &@        \r\n"
				+ "             (&&   .&      (%      @@      &&    @.      @ .&@ /.    .&@        \r\n"
				+ "            .&%    &        @    .%%&      &%    @       (&@.        ,&@        \r\n"
				+ "            @@      &%   .%&    @  &&(..,,/&#     &%,,*@@.           *&@        \r\n"
				+ "           &&.              (. @ %&%.      #@&@    *@@               (&%        \r\n"
				+ "           &&           &, &, @%&.   @(  %#   @&%&&                 ,&&*        \r\n"
				+ "        .%@&%.        ((  @, @&&    @     */   &@        ,#&@&&&&@@&&@          \r\n"
				+ "         &&     .*(%@@@@@@@@@@&&    /@.  #@    .&&&&@@#/.           &&          \r\n"
				+ "         @&,                  @@               ,&#                  &@          \r\n"
				+ "         /&@      .(%@@&@@%*. .&@             .&&, .,*(#@@@@&&&@@@@&&.          \r\n"
				+ "          @&&&@#,     /  @  @(&&@&&.        %&@  %&&&*@ (/ .      @&#           \r\n"
				+ "            .&@  @ .@  @( @&@,     (@@&&@@#.         #&&%& ,% @  &&,            \r\n"
				+ "              @&. %& @&&&@   &,  &,  (@@@/   .&   @      (&&& ,&&&              \r\n"
				+ "                @@,#&&@.     ,@&&&  @    ,@   /@@@          &&&%                \r\n"
				+ "                 &&&*      /@@&      #@@@,      *@(&%       @&&/                \r\n"
				+ "                 &&&,     *#  .&      &@&       &   @    &&&&%                  \r\n"
				+ "                    &&@             ,@   @           *@&&@/                     \r\n"
				+ "                        /@@%                    &@&&&@.                         \r\n"
				+ "                               ,%@@&&&&&&&&&@@#.  ");

		location=TheMillenniumFalconL.getInstance();
		notifyObservers("Where do you want to go? (type in \"stay\" to stay on the millennium falcon)");
		Scanner s = new Scanner(System.in);
		System.out.print(">");
		String line = s.nextLine();
		String[] lines = line.split(" ");

		try {
			if(lines[0].equals("travel")|| lines[0].equals("Travel")) {

				if(lines.length!=3) {

					throw new Exception();
				}

				else {
					travel(lines[2]);
				}

			}

			else if (lines[0].equals("stay")|| lines[0].equals("Stay")) {

				location= TheMillenniumFalconL.getInstance();
				falcon.loc=OuterSpace.getInstance();
				notifyObservers("You are now free to discover the falcon! Go ahead!");
			}
		}
		catch(Exception c) {

			notifyObservers("Invalid Command. Did you mean travel to <Location> or \"stay\"?");
		}

	}


	public void travel(String place) {



		if(place.equals("The_Death_Star")) {

			//will not change falcon location as it can only be in outer space
			location= TheDeathStar.getInstance();
			notifyObservers("Welcome to "+ location.name+"!");

		}

		else if(place.equals("Tatooine")) {

			//will not change falcon location as it can only be in outer space
			location=Tatooine.getInstance();
			notifyObservers("Welcome to "+ location.name+"!");
		}

		else {

			notifyObservers("The location does not exist in this world.");
		}


	}



}


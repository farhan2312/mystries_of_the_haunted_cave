package com.company;

public class Food extends Objects {

    int quantity;
    public Food()
    {

        super("Food","Consumable");
        quantity = 0;
    }
    public Food(int q) {
    	quantity=q;
    }

    public void AddFood()
    {
        quantity++;
    }
    
    public void DepleteFood()
    {
    	quantity--;
    }

}

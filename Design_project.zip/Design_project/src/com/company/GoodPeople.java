package com.company;

public interface GoodPeople {

    public String good();
}

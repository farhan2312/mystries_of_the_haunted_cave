package com.company;

import java.util.ArrayList;

public class Forest extends Location {

	private static Forest instance;
    public static synchronized Forest getInstance(){

        if(instance == null){
            instance = new Forest();
        }
        return instance;
    }

    private Forest(){


        name = "The Mythical Forest";
        description= "";

        //*********MYTHICALS***********\\
        ArrayList<Mythicals>mythicals=new ArrayList<Mythicals>();	
        //assigning each mythical with a name, can display when a mythical is killed
        for(int i=0; i<100; i++)
        {
        	Mythicals myt = new Mythicals();
        	mythicals.add(myt);
        	mythicals.get(i).name="Mythical #"+i+1;
        }
        
        //add weapon here
        
        //*********KING***********\\
        King king = King.getInstance();
        ArrayList<Object> inventory_King = new ArrayList<Object>();
        Spear spear_King=new Spear();
        inventory_King.add(spear_King);
        
        //*******SORCERER**********\\
        pandoraMagnus Pandora_Magnus=pandoraMagnus.getInstance();
        ArrayList<Object> inventory_Magnus = new ArrayList<Object>();
        Excalibur excalibur=Excalibur.getInstance();
        inventory_Magnus.add(excalibur);
        
        
        //characters in the location
        ArrayList<Character>characters= new ArrayList();
        for(int i=0; i<100; i++)
        {
        	characters.add(mythicals.get(i));
        }
        characters.add(king);
        characters.add(Pandora_Magnus);
        
        
       //objects in the location
        objects=  new ArrayList<Object>();

        //objects include character inventories
        for(int i=0; i<inventory_King.size(); i++) {

            objects.add(inventory_King.get(i));
        }
        objects.add(inventory_Magnus);
        //add mythicals inventory
        
        //Wood and Food present in this location
        Wood w = new Wood(10);//Wood present in the Forest
        Food f= new Food(10);//Food present in the Forest
        objects.add(w);
        objects.add(f);
        
      //transport in the location
        transport=new ArrayList<Transport>();
        Horse horse=new Horse();
        transport.add(horse);

    }



}

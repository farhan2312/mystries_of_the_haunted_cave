package com.company;

public class Transport {
	
	double speed;
	String mode;//water, land etc.
	
	Transport(){
		
	}
	Transport(double spd, String m){
		speed=spd;
		mode=m;
	}
}

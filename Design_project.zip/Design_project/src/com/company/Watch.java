package com.company;

public class Watch extends ConcreteSubject implements Runnable{

    int counter;
    private static Watch instance;
    private Watch(){
        super();
        counter =5;
        Thread t = new Thread(this);
        t.start();
    }



    public static synchronized Watch getInstance(){

        if(instance == null){
            instance = new Watch();
        }
        return instance;
    }


    synchronized  public int gettime() {

        return counter;

    }

    public void decrementcounter() {

        counter -=1;
    }
    public void run() {

        while(counter!=0) {

            notifyObservers(counter);
            try {
                Thread.sleep(60000);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            decrementcounter();

        }



    }


}

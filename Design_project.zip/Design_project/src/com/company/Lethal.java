package com.company;

public interface Lethal {
	
	public String lethal();

}

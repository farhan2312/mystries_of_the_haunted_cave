package com.company;

public class Horse extends Transport{
	
	Horse(){
		super(80.0, "Land");
	}
}

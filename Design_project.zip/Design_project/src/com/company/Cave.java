package com.company;

import java.util.ArrayList;

public class Cave extends Location{

    private static Cave instance;
    public static synchronized Cave getInstance(){

        if(instance == null){
            instance = new Cave();
        }
        return instance;
    }

    private Cave(){


        name = "The Pandorian Cave";
        description= "A dark and dreary place where the only sound that can be heard is the drip, " +
                "drip, drip of water from the stalactites. The air is thick with humidity, and it's difficult " +
                "to breathe. The darkness is so thick that it's impossible to see more than a few feet.";

        //*********ERIC***********\\
        Pandorian Eric = new Pandorian ("Eric","I am Kraken's friend" );
        ArrayList<Object> inventory_Eric = new ArrayList<Object>();
        Food food_Eric = new Food();
        Wood wood_Eric = new Wood();
        Pickaxe pickaxe_Eric = new Pickaxe();
        inventory_Eric.add(food_Eric);
        inventory_Eric.add(wood_Eric);
        inventory_Eric.add(pickaxe_Eric);
        //********************************

       


        //*************princess leia**********************
		/*
		 * ArrayList<Object> inventory_princess = new ArrayList<Object>(); DataTape dt
		 * =new DataTape(); inventory_princess.add(dt); ForceUser princess_Leia = new
		 * ForceUser("Princess_Leia_Organa", "Light Force", 3000,
		 * inventory_princess,false);
		 */
        //***************************************

        //*******************Obi*****************************
		/*
		 * ArrayList<Object> inventory_Obi = new ArrayList<Object>(); LightSaber sb_Obi
		 * = new LightSaber(); inventory_Obi.add(sb_Obi); JediMaster Obi_Wan_Kenobi =
		 * new JediMaster("Obi_Wan_Kenobi", 10000, inventory_Obi, "Luke_Skywalker",
		 * true);
		 */
        //********************************************

        //characters in the location
        characters= new ArrayList<Character>();
        //characters.add(Obi_Wan_Kenobi);
        //characters.add(princess_Leia);
        characters.add(Eric);

        objects=  new ArrayList<Object>();

        //objects include character inventories
        for(int i=0; i<inventory_Eric.size(); i++) {

            objects.add(inventory_Eric.get(i));
        }

        Wood w = new Wood(10);//Wood present in the Cave
        Food f= new Food(10);//Food present in the Cave
        objects.add(w);
        objects.add(f);

    }
}


   


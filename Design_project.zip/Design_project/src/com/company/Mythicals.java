package com.company;

import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

public class Mythicals extends Mytheric {
	
	static ArrayList<Objects> inventory = new ArrayList();

	//int count;
	//check if we should have an array list based system or counter
	

	public Mythicals(){
		super("Mythical","Mytheric people",inventory,10);

		//mythicals=new Arraylist<Mytheric>();
	}
	
	/*
	 * public void addMythical(Mythical m){ mythicals.add(m); }
	 * 
	 * public void killMythical(Mythical m) { mythicals.remove(m); }
	 */

}

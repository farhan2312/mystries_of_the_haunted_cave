package com.company;

public class Excalibur extends Weapon{
	private static Excalibur instance;
    public static synchronized Excalibur getInstance(){

        if(instance == null){
            instance = new Excalibur();
        }
        return instance;
    }
    
    private Excalibur(){
	       super("Excalibur","Weapon","The only weapon that can kill the King");  	
    }
	

}

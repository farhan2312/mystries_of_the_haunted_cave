package com.company;

public interface Observer {
    void update(String name);

	void update(int j);

}

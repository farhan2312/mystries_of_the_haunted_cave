package com.company;

public interface Subject {

        public void registerObserver(Observer o);
        public void removeObsever(Observer o);
        public void notifyObservers(String s);
        public void notifyObservers(int j);


}

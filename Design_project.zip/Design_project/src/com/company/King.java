package com.company;

import java.util.ArrayList;

public class King extends Mytheric{
	
	private static King instance;
	static ArrayList<Objects> inventory = new ArrayList(); 	
    public static synchronized King getInstance(){

        if(instance == null){
            instance = new King();
        }
        return instance;
    }
    
    private King(){
   
    	super("King","The Pandorian King",inventory,500);
    
    	
    	//***********************\\
    	//add some special features for king
    	
    	
    }
}

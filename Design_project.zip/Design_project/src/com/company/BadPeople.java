package com.company;

public interface BadPeople {
}

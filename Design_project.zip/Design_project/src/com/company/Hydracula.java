package com.company;

public class Hydracula extends Character implements Lethal {
	
	
	public String lethal() {
		return "Hydraculas rip out the hearts of their enemies and eat them while they are still beating";
		
	}
}

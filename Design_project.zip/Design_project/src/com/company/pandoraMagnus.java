package com.company;

import java.util.ArrayList;

public class pandoraMagnus extends Mytheric{
	
	private static pandoraMagnus instance;
	static ArrayList<Objects> inventory = new ArrayList();
    public static synchronized pandoraMagnus getInstance(){

        if(instance == null){
            instance = new pandoraMagnus();
        }
        return instance;
    }
    
    private pandoraMagnus(){
    	super("Pandora Magnus","The Sorcerer",inventory,100);

    	
    	//***********************\\
    	//add some special features for Sorcerer
    	
    	
    }
}

package com.company;

public class Objects {


    String type;
    String name;
    String description;

    public Objects()
    {
    }
    public Objects(String name, String type, String description)
    {
        this.name = name;
        this.type = type;
        this.description=description;
    }

}

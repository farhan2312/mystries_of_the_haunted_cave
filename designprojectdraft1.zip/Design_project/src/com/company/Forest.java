package com.company;

public class Forest extends Location {


}

package com.company;

public class King {
}

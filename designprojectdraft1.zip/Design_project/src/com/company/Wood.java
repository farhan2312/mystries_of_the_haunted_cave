package com.company;

public class Wood extends Objects {

    int quantity;
    public Wood()
    {
        super("Wood","Consumable");
        quantity = 0;
    }

    public void AddWood()
    {
        quantity++;
    }



}

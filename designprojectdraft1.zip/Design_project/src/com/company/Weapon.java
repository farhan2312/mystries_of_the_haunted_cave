package com.company;

public class Weapon extends Objects{
    String Weapon_Type;
    public Weapon(String name, String Type, String Weapon_Type)
    {
        super(name, "Weapon");
        this.Weapon_Type = Weapon_Type;
    }
}

package com.company;

public class Lake extends Location{
}

package com.company;

import java.util.ArrayList;

public class Character {
String name;
String description;
int hp;
ArrayList<Objects> inventory=null;
    Character(String n, String des, ArrayList<Objects> in){
    	
        name=n;
        description=des;
        inventory = in;
        hp=100;
        
    }
    Character(){
    	name = "Game Character";
    	description = "Character in the Mystery of the Haunted Cave";
    	inventory = new ArrayList<Objects>();
    }
}

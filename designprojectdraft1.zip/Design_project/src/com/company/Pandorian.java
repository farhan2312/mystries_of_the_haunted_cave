package com.company;

public class Pandorian extends Character implements GoodPeople{
    String behavior;
    Pandorian(){
    super();
    behavior=good();
    }
    Pandorian(String n, String des){
        name=n;
        description=des;
    }
    public String good(){
    String info="The Pandorians are highly respected...";
            return info;
    };
}

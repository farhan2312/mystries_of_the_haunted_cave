package com.company;

import java.util.ArrayList;

public class Location {

    String name;
    String description;
    ArrayList<Character> characters=null;  //characters in the location
    ArrayList<Objects> objects=null;  //objects in the location

    Location(){
    	
      characters = new ArrayList<Character>();
      objects = new ArrayList<Objects>();
    }
    
   
}



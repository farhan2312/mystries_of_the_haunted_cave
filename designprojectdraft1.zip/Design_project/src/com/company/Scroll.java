package com.company;
import java.util.Random;

public class Scroll extends Objects{

    Random rand = new Random();
    String content;


    public Scroll() {
        super("Scroll", "stores data");
        this.content  = Integer.toString(rand.nextInt(10000));

    }

    public String ret_contents() {
        return content;
    }

}

package com.company;

public class Pickaxe extends Weapon{

    public Pickaxe() {
       super("Pick Axe","Weapon","Farming Tool");
    }
}

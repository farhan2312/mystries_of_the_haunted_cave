package com.company;

public class Mythricals {
}

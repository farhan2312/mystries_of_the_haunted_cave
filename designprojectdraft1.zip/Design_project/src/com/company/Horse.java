package com.company;

public class Horse {
}

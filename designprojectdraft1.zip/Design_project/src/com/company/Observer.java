package com.company;

public interface Observer {
    void update(String name);
    

}

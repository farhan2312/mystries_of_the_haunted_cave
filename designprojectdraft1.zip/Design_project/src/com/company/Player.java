package com.company;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;
    public class Player extends Character implements Subject{

        Location location = new Location();
        ArrayList<String> scroll; //noticed that we already have Character class
        protected ArrayList observers;
        Watch w;
        ArrayList<Boolean> Task_Completion; //at index 1, bool value for task 1 and so on
        ArrayList<String> Tasks= new ArrayList<String>();
        
        private Player(Watch w){
            this.w = w;
            location = Cave.getInstance();//player starts off in the cave
            observers = new ArrayList();
            Scanner scc= new Scanner(System.in);
            System.out.print("Enter Player name: ");
            name = scc.next();
        }


        public static Player createplayer(Watch w) {
        	
            return new Player(w);

        }


        public void start_game() {


            String Game_Message ="                                                                                                                                                                                                                                       \n" +
                    "@@@       @@@@@@@@   @@@@@@@@  @@@@@@@@  @@@  @@@  @@@@@@@       @@@@@@   @@@@@@@@     @@@@@@@  @@@  @@@  @@@@@@@@     @@@  @@@   @@@@@@   @@@  @@@  @@@  @@@  @@@@@@@  @@@@@@@@  @@@@@@@       @@@@@@@   @@@@@@   @@@  @@@  @@@@@@@@  \n" +
                    "@@@       @@@@@@@@  @@@@@@@@@  @@@@@@@@  @@@@ @@@  @@@@@@@@     @@@@@@@@  @@@@@@@@     @@@@@@@  @@@  @@@  @@@@@@@@     @@@  @@@  @@@@@@@@  @@@  @@@  @@@@ @@@  @@@@@@@  @@@@@@@@  @@@@@@@@     @@@@@@@@  @@@@@@@@  @@@  @@@  @@@@@@@@  \n" +
                    "@@!       @@!       !@@        @@!       @@!@!@@@  @@!  @@@     @@!  @@@  @@!            @@!    @@!  @@@  @@!          @@!  @@@  @@!  @@@  @@!  @@@  @@!@!@@@    @@!    @@!       @@!  @@@     !@@       @@!  @@@  @@!  @@@  @@!       \n" +
                    "!@!       !@!       !@!        !@!       !@!!@!@!  !@!  @!@     !@!  @!@  !@!            !@!    !@!  @!@  !@!          !@!  @!@  !@!  @!@  !@!  @!@  !@!!@!@!    !@!    !@!       !@!  @!@     !@!       !@!  @!@  !@!  @!@  !@!       \n" +
                    "@!!       @!!!:!    !@! @!@!@  @!!!:!    @!@ !!@!  @!@  !@!     @!@  !@!  @!!!:!         @!!    @!@!@!@!  @!!!:!       @!@!@!@!  @!@!@!@!  @!@  !@!  @!@ !!@!    @!!    @!!!:!    @!@  !@!     !@!       @!@!@!@!  @!@  !@!  @!!!:!    \n" +
                    "!!!       !!!!!:    !!! !!@!!  !!!!!:    !@!  !!!  !@!  !!!     !@!  !!!  !!!!!:         !!!    !!!@!!!!  !!!!!:       !!!@!!!!  !!!@!!!!  !@!  !!!  !@!  !!!    !!!    !!!!!:    !@!  !!!     !!!       !!!@!!!!  !@!  !!!  !!!!!:    \n" +
                    "!!:       !!:       :!!   !!:  !!:       !!:  !!!  !!:  !!!     !!:  !!!  !!:            !!:    !!:  !!!  !!:          !!:  !!!  !!:  !!!  !!:  !!!  !!:  !!!    !!:    !!:       !!:  !!!     :!!       !!:  !!!  :!:  !!:  !!:       \n" +
                    " :!:      :!:       :!:   !::  :!:       :!:  !:!  :!:  !:!     :!:  !:!  :!:            :!:    :!:  !:!  :!:          :!:  !:!  :!:  !:!  :!:  !:!  :!:  !:!    :!:    :!:       :!:  !:!     :!:       :!:  !:!   ::!!:!   :!:       \n" +
                    " :: ::::   :: ::::   ::: ::::   :: ::::   ::   ::   :::: ::     ::::: ::   ::             ::    ::   :::   :: ::::     ::   :::  ::   :::  ::::: ::   ::   ::     ::     :: ::::   :::: ::      ::: :::  ::   :::    ::::     :: ::::  \n" +
                    ": :: : :  : :: ::    :: :: :   : :: ::   ::    :   :: :  :       : :  :    :              :      :   : :  : :: ::       :   : :   :   : :   : :  :   ::    :      :     : :: ::   :: :  :       :: :: :   :   : :     :      : :: ::   \n" +
                    "                                                                                                                                                                                                                                       ";

            notifyObservers(Game_Message);
            notifyObservers("You've woken up dazed. You look around, you're in an empty cave. It's dark and murky");
            notifyObservers("Enter a command (try look)");

        }


        public void look(){

            // The player can “look” to know the location’s description and characters/objects present.
            // Objects can exist in a location or in a character’s inventory.

            notifyObservers("You are in "+ location.name+ " which is a "+location.description+"\n");

            if(location.characters.size()!=0) {
                notifyObservers("At "+ location.name+" you find:");
                for(int i=0; i<location.characters.size();i++) {
                    System.out.print(location.characters.get(i).name+" who ");
                    System.out.print(location.characters.get(i)+"\n");

                }
            }
            else {

                notifyObservers("This place looks deserted. There's no one around...");
            }

            if(location.objects!=null) {

                notifyObservers("\nYou found the following objects:\n");
                notifyObservers("--Some objects may have a quantity > 1");
                for(int i=0; i<location.objects.size(); i++) {

                    notifyObservers(location.objects.get(i).name+" ");

                }
            }

            else {

                notifyObservers("There are no objects around. Stop looking");
            }



        }

        public void searchCharacter(String name) {

            int i ;
            Boolean found = false;
            Boolean inventory_found = false;
            for(i=0; i< location.characters.size();i++) {

                if(name.equals(location.characters.get(i).name)){
                    found = true;
                    if(location.characters.get(i).inventory!=null) {
                        inventory_found = true;
                        notifyObservers(name+ " has the following inventory: ");
                        for(int j=0; j<location.characters.get(i).inventory.size();j++) {

                            System.out.print(location.characters.get(i).inventory.get(j).name+" ");

                        }
                        notifyObservers(" ");
                    }
                    break;
                }

            }

            if(!found) {
                notifyObservers("Character is not at this location!");
            }
            if(found && !inventory_found) {

                notifyObservers("OOPS "+name+" does not have anything in their inventory!");
            }

        }

        public void inspectObject(String obj) {

            //inspect objects in location
            Boolean foundinloc = false;
            if(location.objects!=null) {
                for(int i =0; i<location.objects.size();i++) {
                	
                	
                    if(obj.equals(obj.equals(location.objects.get(i).name))){

                        notifyObservers(location.objects.get(i).description);
                        foundinloc = true;
                        break;
                    }

                }
            }
            
 

            Boolean foundininven = false;
            //inspect objects in inventory
            if(!foundinloc) {
                for(int i =0; i<location.characters.size();i++) {

                    if(location.characters.get(i).inventory!=null) {

                        for(int j =0; j<location.characters.get(i).inventory.size();j++) {


                            if(obj.equals(location.characters.get(i).inventory.get(j).name)){

                                notifyObservers(location.characters.get(i).inventory.get(j).description+"\n");
                                foundininven = true;
                                return;

                            }
                        }

                    }
                }

            }

            //inspect objects in player in inventory
            if(!foundinloc && !foundininven) {

                if(inventory!=null) {

                    for(int i =0; i<inventory.size();i++) {

                        if(obj.equals(inventory.get(i).name)){

                            notifyObservers(inventory.get(i).description+"\n");
                            foundininven = true; //we're using the same boolean variable for player and character inventory
                            return;

                        }
                    }

                }


            }




            //if user is inspecting an object that is neither in their inventory nor their location
            if(!foundinloc && !foundininven) {

                notifyObservers("What is a/an "+ obj+"? No such thing exists in your location, your inventory, or any available character inventory");
            }



        }

        public void acquireObject(String obj) {

            Boolean acquire_found = false;

            if(location.objects!=null) { //only enter if location has any objects
            	
                for(int i =0; i<location.objects.size();i++) {
                	
                    if(obj.equals(location.objects.get(i).name)){

                        inventory.add(location.objects.get(i)); //add object to inventory
                        location.objects.remove(i); //remove object from location
                        acquire_found = true; //object was found in location
                        notifyObservers(obj+ " was added to your inventory\n");
                        notifyObservers("Your inventory now has the following items:\n");
                        for(int j=0; j<inventory.size(); j++) { //printing out player's inventory

                            notifyObservers(inventory.get(j).name+" ");

                        }
                        notifyObservers(" ");
                        break;
                    }

                }

            }
            else {

                notifyObservers("There aren't any objects in your location!!!");
                return;
            }

            //if user is trying to acquire an object that does not exist in their location
            if(!acquire_found) {

                notifyObservers("You are trying to acquire an object that does not exist in your location!");
            }


        }
        //The player can “request <object> from <character>” to acquire an object that is already in another character’s inventory.
        public void requestObject(String obj, String chara){

            Boolean foundchar = false;
            Boolean foundobj = false;
            //CHECK IF SITH LORD!
            for(int i=0; i<location.characters.size();i++) {

                if(chara.equals(location.characters.get(i).name)) {


                    for(int j =0; j< location.characters.get(i).inventory.size(); j++) {

                        if(obj.equals(location.characters.get(i).inventory.get(j).name)) {

                            notifyObservers(chara+" has agreed to offer you their "+obj);
                            foundobj = true;
                            inventory.add(location.characters.get(i).inventory.get(j));
                            location.characters.get(i).inventory.remove(location.characters.get(i).inventory.get(j));

                            notifyObservers(obj+ " was added to your inventory\n");
                            notifyObservers("Your inventory now has the following items:\n");
                            for(int k=0; k<inventory.size(); k++) { //printing out player's inventory

                                notifyObservers(inventory.get(k).name+" ");

                            }
                            notifyObservers(" ");


                            break;
                        }
                    }
                    foundchar = true;
                    break;
                }
            }

            if(!foundchar) {
                notifyObservers(chara+" is not in this location.... You are talking to yourself :/");
            }
            else if(!foundobj) {
                notifyObservers(chara+" does not have a/an "+ obj+" in their inventory! Ask for something else maybe?");
            }

        }


        
        public void fightCharacter(String chara, String obj) {

            Boolean foundweapon=false, foundchar=false;
            int index=0;
            for(int i=0; i<location.characters.size();i++) {

                if(chara.equals(location.characters.get(i).name)) {

                    foundchar = true;//character exists in current location
                
                    index = i;

                        break;
                    }

              }
            


            for(int j=0; j<inventory.size();j++) {//search through inventory

                if(inventory.get(j).type=="Weapon") {//if inventory contains a weapon
                    foundweapon = true;
                    break;

                }

            }

            if(!foundchar) {

                notifyObservers(chara+" is not here! You're trying to fight the air...you look goofy");
            }

          

            else if(!foundweapon) {

                notifyObservers("Are you seriously trying to fight without a weapon?? You have a death wish don't you?");
            }

           
            else {


                Boolean inInven = false;
                for(int k=0; k<location.characters.get(index).inventory.size(); k++) {

                    if(obj.equals(location.characters.get(index).inventory.get(k).name)) {
                        notifyObservers("You have defeated "+ chara);
                        inventory.add(location.characters.get(index).inventory.get(k));
                        location.characters.get(index).inventory.remove(location.characters.get(index).inventory.get(k));
                        inInven = true;
                        break;
                    }

                }
                if(!inInven) {

                    notifyObservers(chara+ " does not have a/an "+ obj);
                    return;
                }
                notifyObservers(obj+ " was added to your inventory\n");
                notifyObservers("Your inventory now has the following items:\n");
                for(int k=0; k<inventory.size(); k++) { //printing out player's inventory

                    notifyObservers(inventory.get(k).name+" ");

                }
                notifyObservers(" ");

            }
        }


        public void addtoscroll(char c) {
        	
        	scroll.add(c+" ");
        	
        }
        
        public void readscroll() {
        	
        	if(scroll.size()==0) {
        		
        		notifyObservers("The scroll is currently empty. Try completing your tasks");
        		return;
        	}
        	
        	notifyObservers("   ▄▄▄▄▄   ▄█▄    █▄▄▄▄ ████▄ █    █         ████▄ ▄████      ▄████  █▄▄▄▄ ▄███▄   ▄███▄   ██▄   ████▄ █▀▄▀█ \r\n"
        			+ "  █     ▀▄ █▀ ▀▄  █  ▄▀ █   █ █    █         █   █ █▀   ▀     █▀   ▀ █  ▄▀ █▀   ▀  █▀   ▀  █  █  █   █ █ █ █ \r\n"
        			+ "▄  ▀▀▀▀▄   █   ▀  █▀▀▌  █   █ █    █         █   █ █▀▀        █▀▀    █▀▀▌  ██▄▄    ██▄▄    █   █ █   █ █ ▄ █ \r\n"
        			+ " ▀▄▄▄▄▀    █▄  ▄▀ █  █  ▀████ ███▄ ███▄      ▀████ █          █      █  █  █▄   ▄▀ █▄   ▄▀ █  █  ▀████ █   █ \r\n"
        			+ "           ▀███▀    █             ▀    ▀            █          █       █   ▀███▀   ▀███▀   ███▀           █  \r\n"
        			+ "                   ▀                                 ▀          ▀     ▀                                  ▀   \r\n"
        			+ "                                                                                                             ");//The Edge at patorjk
        	
        	
        	notifyObservers("                                                                                          \r\n"
        			+ "                               .!5G5^                                                               \r\n"
        			+ "                             ~GGJ^:~&&P7:                                                           \r\n"
        			+ "                           :BG~. ..:B~^?PG57:                                                       \r\n"
        			+ "                          !@7......!:.....^75PPY!:.                                                 \r\n"
        			+ "                         ^@! .................:~?YPP5J!^.                                           \r\n"
        			+ "                         &5 ........................:~?Y5PP5J7~:.                                   \r\n"
        			+ "                        !@:................................:~7JY5PP5Y?!~:.                          \r\n"
        			+ "                        G#.........................................:^~7JY5PP5YJ!^:.                 \r\n"
        			+ "                        &5 .................................................::~G@&#BGPY~            \r\n"
        			+ "                        &J ................................................. ^#G~....:~P#~          \r\n"
        			+ "                        &J .................................................^@Y........ ~&J         \r\n"
        			+ "                        &Y ....................................:^^:.........#B ......... ^@!        \r\n"
        			+ "                        &P ......................................:~7?!^... ~@5^.......... Y&        \r\n"
        			+ "                        GB..........................................:!YP5?^P@P@5..........^@^       \r\n"
        			+ "                        Y&..............................................^JB@#^7&B:.........@!       \r\n"
        			+ "                        !@............................................... .@G~!!B&!.......:@^       \r\n"
        			+ "                        :@^................................................@#PPP5#@G^. .. P&        \r\n"
        			+ "                        .@!...............................................:@GJ5PGGB@@BJ~!P#.        \r\n"
        			+ "                         &J ..............................................:@~      ..~???~          \r\n"
        			+ "                         #G ...............................................@!                       \r\n"
        			+ "                         G#................................................@7                       \r\n"
        			+ "                         5& ...............................................&J                       \r\n"
        			+ "                         Y@Y~..............................................&5                       \r\n"
        			+ "                         Y@?PGY!:..........................................BB                       \r\n"
        			+ "                         5&  .^!??!:...................................... P#                       \r\n"
        			+ "                         G#.......:^^:.................................... Y&                       \r\n"
        			+ "                         &P ...............................................?@                       \r\n"
        			+ "                        .@7................................................!@.                      \r\n"
        			+ "          .^7JJY~       !@.................................................^@:                      \r\n"
        			+ "         5BY7~^!5B5^    #P.................................................:@~                      \r\n"
        			+ "        &G. ......!5B5^7@:..................................................@7                      \r\n"
        			+ "       ~@: ..........~Y#&J^. ...............................................&J                      \r\n"
        			+ "       .@J:........... .^JGB5!:. ...........................................&5                      \r\n"
        			+ "        J@PJ?~:.......... .:!5BGY~:. .......................................#P                      \r\n"
        			+ "         J&Y!7?7!^........... .:75GGY!:.....................................#G                      \r\n"
        			+ "          :B#J~~!!!~^..............:7YGG5?~:................................#G                      \r\n"
        			+ "            ^G#P?!~~!~~^:............ .:~J5GG5J!^:..........................#G                      \r\n"
        			+ "              .7PBG5?!~~~~^:..............::^!7J5GGPY?!^:.... ..............&5                      \r\n"
        			+ "                  :?PBG5?!~~~^:..............^~~^:::~J&@@&&#GY~...:^~~~:.. .&J                      \r\n"
        			+ "                      :?PBG5?!~~~^:.............:!??J&@@@@@@@@@#:....:~7JYY?@!                      \r\n"
        			+ "                          ^?PBGY7!~~~^::.......... J@@@@@@@@@@@@? ........^J@.                      \r\n"
        			+ "                              ^?GBGY7!~~~~^:.......#@@@@@@@@@@@@~......... Y&                       \r\n"
        			+ "                                  ^JGBGY7!~~~~^:...@GJ#@@@@@@@@J...........&Y                       \r\n"
        			+ "                                     .^JGBGY7!~~~~^&P .^J#@@@@?.......... 7@.                       \r\n"
        			+ "                                         .^JGBGY7~~##... .:JG^ ..........:@?                        \r\n"
        			+ "                                             .^JGBP#@: ................ .&G                         \r\n"
        			+ "                                                 .^J#GY~:............ .!&Y                          \r\n"
        			+ "                                                     .~JPP5?~^:....:~JBG:                           \r\n"
        			+ "                                                         .:!?Y5PPPP5Y!.                             ");
        	
        	notifyObservers("The following characters are displayed on the scroll infront of you: ");
        	for(int i=0; i<scroll.size();i++) {
        		
        		notifyObservers(scroll.get(i));
        	}
        }
        
        public void Tasks() {
        	
        	notifyObservers("Complete these tasks to uncover the mystery word on the scroll of freedom:");
        	int index=1;
        	for(int i=0; i<Tasks.size();i++) {
        		
        		if(Task_Completion.get(i)== true) {
        			
        			notifyObservers(index+ ". "+ Tasks.get(i));
        			index++;
        		}
        		
        	}
        	
        	
        }

        public void registerObserver(Observer o){
        	
            observers.add(o);
            
        }
        
        public void removeObsever(Observer o){
        	
            int i = observers.indexOf(o);
            if (i>=0) observers.remove(i);
            
        }
        
        public void notifyObservers(String s){
        	
            for (int i =0; i<observers.size(); i++)
            {// TODO Auto-generated method stub
                Observer observer = (Observer)observers.get(i);
                observer.update(s);
            }
            
        }

    }


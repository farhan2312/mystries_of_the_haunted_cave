package com.company;

public class Food extends Objects {

    int quantity;
    public Food()
    {

        super("Food","Consumable");
        quantity = 0;
    }

    public void AddFood()
    {
        quantity++;
    }

}

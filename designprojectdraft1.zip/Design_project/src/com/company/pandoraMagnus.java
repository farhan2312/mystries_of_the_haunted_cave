package com.company;

public class pandoraMagnus {
}

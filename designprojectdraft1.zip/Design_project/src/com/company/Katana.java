package com.company;

public class Katana extends Weapon{


    public Katana() {
        super("Katana", "Weapon", "Assult");
    }
}

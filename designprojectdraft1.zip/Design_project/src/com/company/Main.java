package com.company;

import java.util.Scanner;

public class Main {

    public static void main (String[] args) {

        Watch w = Watch.getInstance();

        Player p = Player.createplayer(w);
       
        UI ui = UI.getInstance(w,p);

       

        Scanner sc= new Scanner(System.in);

        //start game
        p.start_game();

            System.out.print(">");
            String line = sc.nextLine();
            String[] lines = line.split(" ");
            String command = lines[0];

            try {
                if(command.equals("look")|| command.equals("Look")) {

                    if(lines.length>=2) {

                        throw new Exception();

                    }

                    else {

                        p.look();
                    }


                }
            }catch(Exception a) {

                System.out.println("Iook?");
            }


            try {
                if(lines[0].equals("search")|| lines[0].equals("Search")) {

                    if(lines.length>2) {

                        throw new Exception();

                    }

                    else {

                        p.searchCharacter(lines[1]);
                    }

                }
            }catch(Exception b) {

                System.out.println("Invalid Command. Did you mean: search <Character name>?");
            }

            //inspectObject
            try {
                if(lines[0].equals("inspect")|| lines[0].equals("Inspect")) {

                    if(lines.length!=2) {

                        throw new Exception();
                    }

                    else {
                        p.inspectObject(lines[1]);
                    }
                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean inspect <object>?");
            }



            //acquire object

            try {
                if(lines[0].equals("acquire")|| lines[0].equals("Acquire")) {

                    if(lines.length!=2) {

                        throw new Exception();
                    }

                    else {
                        p.acquireObject(lines[1]);
                    }
                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean acquire <object>?");
            }



            //fightCharacter
            try {
                if(lines[0].equals("fight")|| lines[0].equals("Fight")) {

                    if(lines.length!=4) {

                        throw new Exception();
                    }

                    else {
                        p.fightCharacter(lines[1], lines[3]);
                    }
                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean fight <Character> for <Object>?");
            }



            //
            try {
                if(lines[0].equals("request")|| lines[0].equals("Request")) {

                    if(lines.length!=4) {

                        throw new Exception();
                    }

                    else {
                        p.requestObject(lines[1],lines[3]);
                    }
                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean request <Object> from <Character>?");
            }




            try {
                if(lines[0].equals("exit")|| lines[0].equals("Exit")) {

                    if(lines.length>1) {

                        throw new Exception();
                    }

                    System.out.println("exiting...");
                    System.exit(0);

                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean exit?");
            }


            try {
                if(lines[0].equals("Scroll")|| lines[0].equals("scroll")) {

                    if(lines.length>1) {

                        throw new Exception();
                    }

                    p.readscroll();
                  

                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean <scroll>?");
            }

            try {
                if(lines[0].equals("Tasks")|| lines[0].equals("tasks")) {

                    if(lines.length>1) {

                        throw new Exception();
                    }

                    p.Tasks();
                  

                }

            }catch(Exception c) {

                System.out.println("Invalid Command. Did you mean <Tasks>?");
            }
           

        }


    }


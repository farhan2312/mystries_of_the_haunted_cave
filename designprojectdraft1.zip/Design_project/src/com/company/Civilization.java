package com.company;

public class Civilization extends Location{
}
